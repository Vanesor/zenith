--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18 (Ubuntu 14.18-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.18 (Ubuntu 14.18-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: committee_members; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.committee_members (id, committee_id, role_id, user_id, status, joined_at, term_start, term_end, achievements, created_at, updated_at) VALUES ('efdde746-50c9-48a0-86a1-3d991d813b6b', '9e2a45e8-88e0-4998-bbc1-1ab68cf9f989', 'bd8838dc-d4db-4bf9-a483-fc970b01d35a', '8694ff1f-1d1e-4a7b-8ecb-eebda2c937d3', 'active', '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30', '2026-08-20 11:30:17.917+05:30', NULL, '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30');
INSERT INTO public.committee_members (id, committee_id, role_id, user_id, status, joined_at, term_start, term_end, achievements, created_at, updated_at) VALUES ('8663ee16-2776-46f5-91fb-567490ead94f', '9e2a45e8-88e0-4998-bbc1-1ab68cf9f989', '61066b5a-6b0c-411a-83fd-ea3fa81893b5', '241f4f32-458e-410e-b2f2-6dcfda992455', 'active', '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30', '2026-08-20 11:30:17.917+05:30', NULL, '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30');
INSERT INTO public.committee_members (id, committee_id, role_id, user_id, status, joined_at, term_start, term_end, achievements, created_at, updated_at) VALUES ('d8102f60-2815-4571-8806-e4979624b577', '9e2a45e8-88e0-4998-bbc1-1ab68cf9f989', '60880bea-c878-4fe6-9388-8b4384ad2a59', '53cbed56-2bc7-4faf-bd6e-5f953de4dfa5', 'active', '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30', '2026-08-20 11:30:17.917+05:30', NULL, '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30');
INSERT INTO public.committee_members (id, committee_id, role_id, user_id, status, joined_at, term_start, term_end, achievements, created_at, updated_at) VALUES ('9b0fe363-33c3-44be-9151-ac6c3813a55e', '9e2a45e8-88e0-4998-bbc1-1ab68cf9f989', '885e95e5-f639-43d9-b5a0-c1fa555e0b24', '7c36ecbe-44d3-40df-8b8b-886e5385e839', 'active', '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30', '2026-08-20 11:30:17.917+05:30', NULL, '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30');
INSERT INTO public.committee_members (id, committee_id, role_id, user_id, status, joined_at, term_start, term_end, achievements, created_at, updated_at) VALUES ('68ae4f2b-8b6c-40f6-be82-36ae77bf252b', '9e2a45e8-88e0-4998-bbc1-1ab68cf9f989', 'e74c3e2f-3bdf-40e5-9bc2-a2ca07d81b1e', '21a95efa-ccfa-4c4c-af7f-50cfa0a35053', 'active', '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30', '2026-08-20 11:30:17.917+05:30', NULL, '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30');
INSERT INTO public.committee_members (id, committee_id, role_id, user_id, status, joined_at, term_start, term_end, achievements, created_at, updated_at) VALUES ('43fe11fe-8263-44bb-8190-5ec39dc7ee7b', '9e2a45e8-88e0-4998-bbc1-1ab68cf9f989', '728861c2-df1f-47b2-81b4-d892b4ee819e', '9755eab9-39cb-443b-9cca-853d727afe40', 'active', '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30', '2026-08-20 11:30:17.917+05:30', NULL, '2025-08-20 11:30:17.917+05:30', '2025-08-20 11:30:17.917+05:30');


--
-- PostgreSQL database dump complete
--

