--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18 (Ubuntu 14.18-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.18 (Ubuntu 14.18-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('a874db74-a981-49de-8066-7c13280d5dda', '41ad1a02-02a7-4b65-a464-0cb72a13b355', 'task 2', '2', 'TE93DA47-2', 'task', 'medium', 'todo', '550e8400-e29b-41d4-a716-446655440020', '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, '2025-08-26 00:00:00+05:30', NULL, false, '2025-08-24 09:36:46.923063+05:30', '2025-08-24 10:37:22.308696+05:30');
INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('80811692-3145-4557-8d74-a151d2d0e7a5', '41ad1a02-02a7-4b65-a464-0cb72a13b355', 'htaa', 'ef', 'TE93DA47-5', 'task', 'medium', 'in_progress', NULL, '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, '2025-08-27 00:00:00+05:30', NULL, false, '2025-08-24 09:38:04.623443+05:30', '2025-08-24 10:37:25.076507+05:30');
INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('6df975a8-f72b-42d7-b732-5d6de3a9b89c', '41ad1a02-02a7-4b65-a464-0cb72a13b355', 'ifsgd', 'regt', 'TE93DA47-6', 'task', 'medium', 'in_progress', NULL, '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, NULL, NULL, false, '2025-08-24 09:38:21.673498+05:30', '2025-08-24 10:37:26.700074+05:30');
INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('e89dbb9b-c9b1-4da4-b012-731344cb7ff3', '41ad1a02-02a7-4b65-a464-0cb72a13b355', 'dafkj', 'adsf', 'TE93DA47-4', 'task', 'medium', 'done', NULL, '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, '2025-08-28 00:00:00+05:30', NULL, false, '2025-08-24 09:37:47.209637+05:30', '2025-08-24 10:37:38.260207+05:30');
INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('180990cd-b534-4216-953a-153fa52e3030', '41ad1a02-02a7-4b65-a464-0cb72a13b355', 'task3', 'ji', 'TE93DA47-3', 'task', 'medium', 'done', NULL, '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, '2025-08-26 00:00:00+05:30', NULL, false, '2025-08-24 09:37:30.610104+05:30', '2025-08-24 10:38:48.616006+05:30');
INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('199bf0e2-7d8e-4968-b769-cf6e8a21619b', '12413e7f-8ff1-47f7-b6d6-91558835948c', 'first', 'test', 'NAGPU046-1', 'task', 'medium', 'done', '550e8400-e29b-41d4-a716-446655440020', '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, '2025-08-29 00:00:00+05:30', NULL, false, '2025-08-24 01:54:45.534999+05:30', '2025-08-24 02:21:50.179887+05:30');
INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('96808225-b8ac-4a08-b995-1fa2523b9dc6', '41ad1a02-02a7-4b65-a464-0cb72a13b355', 'task 1', 'des', 'TE93DA47-1', 'task', 'medium', 'todo', '550e8400-e29b-41d4-a716-446655440020', '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, '2025-08-31 00:00:00+05:30', NULL, false, '2025-08-24 09:35:18.066214+05:30', '2025-08-24 10:16:02.789926+05:30');
INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('89390ffc-7681-4380-9adf-2396d41c3f38', '41ad1a02-02a7-4b65-a464-0cb72a13b355', '0', '0', 'TE93DA47-7', 'task', 'medium', 'done', NULL, '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, NULL, NULL, false, '2025-08-24 10:06:32.317337+05:30', '2025-08-24 10:16:43.857952+05:30');
INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('d52f1cc7-db95-42ae-a514-3307b7d4c7cf', '41ad1a02-02a7-4b65-a464-0cb72a13b355', 'new', 'new', 'TE93DA47-8', 'task', 'medium', 'in_review', NULL, '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, NULL, NULL, false, '2025-08-24 10:06:47.769485+05:30', '2025-08-24 10:16:48.008982+05:30');
INSERT INTO public.tasks (id, project_id, title, description, task_key, task_type, priority, status, assignee_id, reporter_id, parent_task_id, story_points, time_spent_hours, due_date, completed_date, is_completed, created_at, updated_at) VALUES ('66575c54-e22b-46f4-a63f-80915f562b68', '41ad1a02-02a7-4b65-a464-0cb72a13b355', 'ui', 'ae', 'TE93DA47-9', 'task', 'medium', 'in_progress', NULL, '550e8400-e29b-41d4-a716-446655440020', NULL, NULL, 0, NULL, NULL, false, '2025-08-24 10:16:32.152132+05:30', '2025-08-24 10:31:06.223981+05:30');


--
-- PostgreSQL database dump complete
--

